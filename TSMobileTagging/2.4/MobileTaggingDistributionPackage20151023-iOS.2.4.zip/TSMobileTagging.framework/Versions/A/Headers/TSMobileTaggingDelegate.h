/*************************************************
 * TNS SIFO Mobile Application Tagging Framework *
 * (c) Copyright 2010-2013 TNS SIFO, Sweden,          *
 * All rights reserved.                          *
 *************************************************/

/**
 * TNS SIFO Mobile Application Tagging Framework :
 * TagRequestCallbackListener.h :
 * 
 * This protocol is used to receive callbacks from the Tagging framework to know if server requests
 * are succeeded or failed. The information can be used to track errors, handle errors etc.
 */
@protocol TSMobileTaggingDelegate <NSObject>

/**
 * This method is called when a tag has been successfully sent to server
 * and the server has responded with result code 200.
 */
-(void)tagRequestComplete;

/**
 * This method is called when a tag request has failed.
 * No new attempt will be made and it will not be received by the server.
 * @param errorCode The http-response code. Will be 0 if request failed without response.
 */
-(void)tagRequestFailed:(int)errorCode;

@end
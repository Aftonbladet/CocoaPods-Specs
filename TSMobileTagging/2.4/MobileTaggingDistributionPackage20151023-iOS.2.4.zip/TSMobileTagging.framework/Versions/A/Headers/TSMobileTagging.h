/*************************************************
 * TNS SIFO Mobile Application Tagging Framework *
 * (c) Copyright 2010-2013 TNS SIFO, Sweden,     *
 * All rights reserved.                          *
 *************************************************/

#import <UIKit/UIKit.h>
#import <TSMobileTagging/TSMobileTaggingDelegate.h>

/**
 * @mainpage TNS SIFO Mobile Application Tagging Framework
 * 
 * This framework will help you to measure usage of your application using TNS SIFO’s services. 
 * In order to measure traffic, your application needs to send HTTP-requests to a server provided by Mobiletech, 
 * using URLs following a specified pattern with information about your application. 
 * The framework can help you with the whole process, both creating these URLs, as well as sending them to the server. 
 * 
 */

/**
 * This framework will help you to measure usage of your application using TNS SIFO’s services. 
 * In order to measure traffic, your application needs to send HTTP-requests to a server provided by Mobiletech, 
 * using URLs following a specified pattern with information about your application. 
 * The framework can help you with the whole process, both creating these URLs, as well as sending them to the server. 
 * 
 */
@interface TSMobileTagging : NSObject {
	NSString    *mCPID;
	NSString    *mApplicationName;
	NSString    *mRef;
	NSString    *mEuid;
	
	int mNbrOfFailedRequests;
	int mNbrOfSuccessfulRequests;
	id<TSMobileTaggingDelegate>mCallbackListener;
}

@property (nonatomic, copy) NSString *mCPID;
@property (nonatomic, copy) NSString *mApplicationName;
@property (nonatomic, copy) NSString *mRef;
@property (nonatomic, copy) NSString *mEuid;
@property (nonatomic, copy) NSString *mPanelisId;
@property (nonatomic, retain) id<TSMobileTaggingDelegate> mCallbackListener;

/**
 * Call this method upon application start, for example in the init-method of
 * the View, to initialize the framework. Can be called as multiple times without causing damage.
 *
 * The CPID must not be more than 6 characters, it must not be empty and may only contain digits.
 * The Application Name must not be more than 244 characters.
 * The parameters must not be null.
 * If any of the parameters are invalid, nil will be returned and getInstance() will also return nil.
 *
 * @param CPID The ID to identify you as a client/customer on the server. This value will be sent in tags
 * using the "cpid"-attribute. Only digits allowed. Max 6 characters.
 * @param applicationName The name of the application. Only specify the name, the interface will add platform.
 * This value will be sent in tags using the "type"-attribute. Max 244 characters.
 * @param syncWithSIFOPanelenApplication Call to redirect to SIFO Panelen application if needed. 
 * Can be called at a later stage with the instance method syncWithSIFOPanelenApplication.
 * @return The framework instance created with your values. Returns nil if creation failed due to invalid parameters.
 */
+ (TSMobileTagging *)createInstanceWithCPID:(NSString*)CPID applicationName:(NSString*)applicationName syncWithSIFOPanelenApplication:(BOOL)sync;

+ (TSMobileTagging *)createInstanceWithCPID:(NSString *)CPID
                            applicationName:(NSString *)applicationName panelistTrackingOnly:(BOOL)trackPanelistOnly syncWithSIFOPanelenApplication:(BOOL)sync;

/**
 * Deprecated, please use createInstanceWithCPID:applicationName:syncWithSIFOPanelenApplication:.
 * @return The framework instance created with your values. Returns nil if creation failed due to invalid parameters.
 */
+ (TSMobileTagging *)createInstanceWithCPID:(NSString*)CPID applicationName:(NSString*)applicationName __attribute__((deprecated));

+ (TSMobileTagging *)createInstanceWithCPID:(NSString *)CPID 
                            applicationName:(NSString *)applicationName panelistTrackingOnly:(BOOL)trackPanelistOnly __attribute__((deprecated));

/**
 * Call this method upon application start, for example in the init-method of
 * the View, to initialize the framework. Can be called as multiple times without causing damage.
 *
 * The CPID must not be more than 6 characters, it must not be empty and may only contain digits.
 * The Application Name must not be more than 244 characters.
 * The parameters must not be null.
 * If any of the parameters are invalid, nil will be returned and getInstance() will also return nil.
 *
 * @param CPID The ID to identify you as a client/customer on the server. This value will be sent in tags
 * using the "cpid"-attribute. Only digits allowed. Max 6 characters.
 * @param applicationName The name of the application. Only specify the name, the interface will add platform.
 * This value will be sent in tags using the "type"-attribute. Max 244 characters.
 * @param keyChainAccessGroup The access group to use to store user identification.
 * @param syncWithSIFOPanelenApplication Call to redirect to SIFO Panelen application if needed.
 * Can be called at a later stage with the instance method syncWithSIFOPanelenApplication.
 * @return The framework instance created with your values. Returns nil if creation failed due to invalid parameters.
 */
+ (TSMobileTagging *)createInstanceWithCPID:(NSString *)CPID applicationName:(NSString*)applicationName
                        keyChainAccessGroup:(NSString *)keyChainAccessGroup syncWithSIFOPanelenApplication:(BOOL)sync;

+ (TSMobileTagging *)createInstanceWithCPID:(NSString *)CPID applicationName:(NSString*)applicationName
                        keyChainAccessGroup:(NSString *)keyChainAccessGroup panelistTrackingOnly:(BOOL)trackPanelistOnly syncWithSIFOPanelenApplication:(BOOL)sync;

/**
 * Deprecated, please use createInstanceWithCPID:applicationName:keyChainAccessGroup:syncWithSIFOPanelenApplication:.
 * @return The framework instance created with your values. Returns nil if creation failed due to invalid parameters.
 */
+ (TSMobileTagging *)createInstanceWithCPID:(NSString *)CPID applicationName:(NSString*)applicationName 
                        keyChainAccessGroup:(NSString *)keyChainAccessGroup __attribute__((deprecated));

+ (TSMobileTagging *)createInstanceWithCPID:(NSString *)CPID applicationName:(NSString*)applicationName 
                        keyChainAccessGroup:(NSString *)keyChainAccessGroup panelistTrackingOnly:(BOOL)trackPanelistOnly __attribute__((deprecated));

/**
 * Call to get an instance of the framework at any time after initialization. 
 * Returns nil if createInstanceWithCPID:applicationName: has not been called before.
 * 
 * @return The framework instance with your values specified in createInstance, nil if not created.
 */
+ (TSMobileTagging *)getInstance;

/**
 * Call to redirect to SIFO Panelen application if needed.
 * @return The BOOL value indicating if the framework will redirect to the SIFO Panelen application.
 */
- (BOOL)syncWithSIFOPanelenApplication;

/**
 * Call to immediately send a tag to the server using the framework´s http-functionality. 
 * 
 * Use when a page is displayed, for example in the viewWillAppear-method of a View.
 * Strings will be encoded using Latin1 (ISO8859-1) and characters not supported in this character 
 * set will not be stored properly on the server.
 * 
 * The category parameter must not be more than 255 characters.
 * The input strings must not be nil.
 * If any of the parameters are invalid the request will fail and return a value >0.
 * If the request is sent successfully 0 will be returned.
 * 
 * @param category The name of category or page to be tagged. This value will be sent using
 * the "cat"-attribute. Max 255 characters.
 * @return 0 if request is sent successfully, otherwise a value bigger than 0.
 */
- (int)sendTagWithCategory:(NSString*)category;

/**
 * Deprecated, please use sendTagWithCategory:contentName:contentID instead.
 * @return 0 if request is sent successfully, otherwise a value bigger than 0.
 */
- (int)sendTagWithCategory:(NSString*)category extra:(NSString*)extra contentID:(NSString*)contentID __attribute__((deprecated));

/**
 * Deprecated, please use sendTagWithCategory:contentName:contentID instead.
 * @return 0 if request is sent successfully, otherwise a value bigger than 0.
 */
- (int)sendTagWithCategory:(NSString*)category extra:(NSString*)extra contentID:(NSString*)contentID contentName:(NSString*)contentName __attribute__((deprecated));

/**
 * Call to immediately send a tag to the server using the framework´s http-functionality. 
 * 
 * Use when a page is displayed, for example in the viewWillAppear-method of a View.
 * Strings will be encoded using Latin1 (ISO8859-1) and characters not supported in this character set will not be stored properly on the server.
 * 
 * The category parameter must not be more than 255 characters.
 * The contentID must not be more than 255 characters.
 * The input strings must not be nil.
 * If any of the parameters are invalid the request will fail and return a value >0.
 * If the request is sent successfully 0 will be returned.
 * 
 * @param category The name of category or page to be tagged. This value will be sent using
 * the "cat"-attribute. Max 255 characters.
 * @param contentID Value to identify specific content within the category, such as a specific article. Max 255 characters.
 */
- (int)sendTagWithCategory:(NSString*)category contentID:(NSString*)contentID;

/**
 * Call to immediately send a tag to the server using the framework´s http-functionality. 
 * 
 * Use when a page is displayed, for example in the viewWillAppear-method of a View.
 * Strings will be encoded using Latin1 (ISO8859-1) and characters not supported in this character set will not be stored properly on the server.
 * 
 * The category parameter must not be more than 255 characters.
 * The contentID must not be more than 255 characters.
 * The contentName must not be more than 255 characters.
 * The input strings must not be nil.
 * If any of the parameters are invalid the request will fail and return a value >0.
 * If the request is sent successfully 0 will be returned.
 * 
 * @param category The name of category or page to be tagged. This value will be sent using
 * the "cat"-attribute. Max 255 characters.
 * @param contentName Name to identify specific content within the category, such as a specific article. Max 255 characters.
 * @param contentID Value to identify specific content within the category, such as a specific article. Max 255 characters.
 */
- (int)sendTagWithCategory:(NSString*)category contentName:(NSString*)contentName contentID:(NSString*)contentID;

/**
 * Deprecated, please use sendTagWithCategoryArray:contentName:contentID instead.
 * @return 0 if request is sent successfully, otherwise a value bigger than 0.
 */
- (int)sendTagWithCategoryArray:(NSArray*)categories extra:(NSString*)extra contentID:(NSString*)contentID contentName:(NSString*)contentName __attribute__((deprecated));

/**
 * Call to immediately send a tag to the server using the framework´s http-functionality. 
 * 
 * Use when a page is displayed, for example in the viewWillAppear-method of a View.
 * Strings will be encoded using Latin1 (ISO8859-1) and characters not supported in this character set will not be stored properly on the server.
 * 
 * The category list must not contain more than 4 objects and they must not be more than 62 characters each.
 * The contentID must not be more than 255 characters.
 * The contentName must not be more than 255 characters.
 * The input strings must not be nil.
 * If any of the parameters are invalid the request will fail and return a value >0.
 * If the request is sent successfully 0 will be returned.
 * 
 * @param categories Array of names in category structure. This value will be sent using
 * the "cat"-attribute. Max 4 objects with 62 characters each.
 * @param contentID Value to identify specific content within the category, such as a specific article. Max 255 characters.
 * @param contentName Name to identify specific content within the category, such as a specific article. Max 255 characters.
 * @return 0 if request is sent successfully, otherwise a value bigger than 0.
 */
- (int)sendTagWithCategoryArray:(NSArray*)categories contentName:(NSString*)contentName contentID:(NSString*)contentID;

/**
 * Create a URL to use to send a tag to the server, if you want to make the request manually.
 * 
 * You only need to use this method if you are making the HTTP-request yourself. If you want the framework 
 * to make the HTTP-request for you, you only need to use the "sendTagWithCategory"-method.
 * 
 * The category parameter must not be more than 255 characters.
 * The input strings must not be nil.
 * If any of the parameters are invalid nil will be returned.
 * 
 * @param category The name of category or page to be tagged. This value will be sent using
 * the "cat"-attribute. Max 255 characters.
 * @return The String holding the created URL. nil if unsuccessful.
 */
- (NSString*)getURLWithCategory:(NSString*)category;

/**
 * Deprecated, please use getURLWithCategory:contentName:contentID instead.
 * @return 0 if request is sent successfully, otherwise a value bigger than 0.
 */
- (NSString*)getURLWithCategory:(NSString*)category extra:(NSString*)extra contentID:(NSString*)contentID __attribute__((deprecated));


/**
 * Deprecated, please use getURLWithCategory:contentName:contentID instead.
 * @return 0 if request is sent successfully, otherwise a value bigger than 0.
 */
- (NSString*)getURLWithCategory:(NSString*)category extra:(NSString*)extra contentID:(NSString*)contentID contentName:(NSString*)contentName __attribute__((deprecated));

/**
 * Create a URL to use to send a tag to the server, if you want to make the request manually.
 * 
 * You only need to use this method if you are making the HTTP-request yourself. If you want the framework 
 * to make the HTTP-request for you, you only need to use the "sendTagWithCategory:extra:contentID:contentName"-method.
 * The category parameter must not be more than 255 characters.
 * The contentID must not be more than 255 characters.
 * The input strings must not be nil.
 * If any of the parameters are invalid the request will fail and return a value >0.
 * If the request is sent successfully 0 will be returned.
 * 
 * @param category The name of category or page to be tagged. This value will be sent using
 * the "cat"-attribute. Max 255 characters.
 * @param contentID Value to identify specific content within the category, such as a specific article. Max 255 characters.
 * @return The String holding the created URL. nil if unsuccessful.
 */
- (NSString*)getURLWithCategory:(NSString*)category contentID:(NSString*)contentID;

/**
 * Create a URL to use to send a tag to the server, if you want to make the request manually.
 * 
 * You only need to use this method if you are making the HTTP-request yourself. If you want the framework 
 * to make the HTTP-request for you, you only need to use the "sendTagWithCategory:extra:contentID:contentName"-method.
 * The category parameter must not be more than 255 characters.
 * The contentID must not be more than 255 characters.
 * The contentName must not be more than 255 characters.
 * The input strings must not be nil.
 * If any of the parameters are invalid the request will fail and return a value >0.
 * If the request is sent successfully 0 will be returned.
 * 
 * @param category The name of category or page to be tagged. This value will be sent using
 * the "cat"-attribute. Max 255 characters.
 * @param contentID Value to identify specific content within the category, such as a specific article. Max 255 characters.
 * @param contentName Name to identify specific content within the category, such as a specific article. Max 255 characters.
 * @return The String holding the created URL. nil if unsuccessful.
 */
- (NSString*)getURLWithCategory:(NSString*)category contentName:(NSString*)contentName contentID:(NSString*)contentID;

/**
 * Deprecated, please use getURLWithCategoryArray:contentName:contentID instead.
 * @return 0 if request is sent successfully, otherwise a value bigger than 0.
 */
- (NSString*)getURLWithCategoryArray:(NSArray*)category extra:(NSString*)extra contentID:(NSString*)contentID contentName:(NSString*)contentName __attribute__((deprecated));

/**
 * Create a URL to use to send a tag to the server, if you want to make the request manually.
 * 
 * You only need to use this method if you are making the HTTP-request yourself. If you want the framework 
 * to make the HTTP-request for you, you only need to use the "sendTagWithCategoryArray:extra:contentID:contentName"-method.
 * 
 * The category list must not contain more than 4 objects and they must not be more than 62 characters each.
 * The input strings must not be nil.
 * If any of the parameters are invalid nil will be returned.
 * 
 * @param category Array of names in category structure. This value will be sent using
 * the "cat"-attribute. Max 4 objects with 62 characters each.
 * @param contentID Value to identify specific content within the category, such as a specific article.
 * @param contentName Name to identify specific content within the category, such as a specific article. Max 255 characters.
 * @return The String holding the created URL. nil if unsuccessful.
 */
- (NSString*)getURLWithCategoryArray:(NSArray*)category contentName:(NSString*)contentName contentID:(NSString*)contentID;


/**
 * Activate log prints for the framework.
 */
+ (void)setLogPrintsActivated:(BOOL)activated;

/*** Advanced methods *****/

/**
 * Advanced/debugging: Get the number of successful requests since the instance was created.
 * 
 * @return The number of successful requests.
 */
- (int)getNbrOfSuccessfulRequests;

/**
 * Advanced/debugging: Get the number of failed requests since the instance was created.
 * 
 * @return The number of failed requests.
 */
- (int)getNbrOfFailedRequests;

/**
 * Advanced/debugging: Add a callback-listener to get notified when a tag request fails or is successful.
 * 
 * @param callbackListener The callback-listener implementing the TagDataRequestCallbackListener interface. 
 */
- (void)setCallbackListener:(id<TSMobileTaggingDelegate>)callbackListener;

/**
 * Helper
 *
 * @param
 * @return
 */
- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation;

@end

/**
 * The maximum length of the Customer identifier value (CPID)
 */
#define TAGGING_CPID_MAX_LENGTH 6

/**
 * The length of Customer identifier value where measurement provider is Codigo Analytics
 */
#define TAGGING_CPID_LENGTH_CODIGO 32

/**
 * The maximum length of the Application Name (type)
 */
#define TAGGING_APPLICATION_NAME_MAX_LENGTH 244

/**
 * The maximum allowed length of the Category String (cat)
 */
#define TAGGING_CATEGORY_MAX_LENGTH 255

/**
 * The maximum allowed lentgth of the Extra String (ref)
 */
#define TAGGING_EXTRA_MAX_LENGTH 100

/**
 * The maximum allowed length of the Content ID (id)
 */
#define TAGGING_CONTENT_ID_MAX_LENGTH 255

/**
 * The maximum allowed length of the Content Name (name)
 */
#define TAGGING_CONTENT_ID_MAX_LENGTH 255

/**
 * The maximum allowed length of the Content Name (name)
 */
#define TAGGING_CONTENT_NAME_MAX_LENGTH 255

/*
 * Result and error codes
 */
#define TAGGING_SUCCESS 0
#define TAGGING_ERROR_CATEGORY_NULL 1
#define TAGGING_ERROR_CATEGORY_TOO_LONG 2
#define TAGGING_ERROR_EXTRA_NULL 3
#define TAGGING_ERROR_EXTRA_TOO_LONG 4
#define TAGGING_ERROR_CONTENT_ID_NULL 5
#define TAGGING_ERROR_CONTENT_ID_TOO_LONG 6
#define TAGGING_ERROR_CONTENT_NAME_NULL 7
#define TAGGING_ERROR_CONTENT_NAME_TOO_LONG 8
#define TAGGING_ERROR_PANELIST_ID_MISSING 9

/**
 * The URL-base used to connect to the Mobiletech-server.
 */
#define TAGGING_URL_BASE @"https://bh.mobiletech.no/sifo/img?"

/**
 * The URL-base used to connect to the Codigo Analytics-server.
 */
#define TAGGING_CODIGO_URL_BASE @"https://trafficgateway.research-int.se/TrafficCollector?"

/**
 * The prefix added to the application name before added to the type-parameter in
 * tag requests. This value is used on iPhone.
 */
#define TAGGING_APP_PREFIX_IPHONE @"APP_IPHONE_"

/**
 * The prefix added to the application name before added to the type-parameter in
 * tag requests. This value is used on iPad.
 */
#define TAGGING_APP_PREFIX_IPAD @"APP_IPAD_"

/**
 * The value to be used for the EUIDQ-parameter in tag requests.
 */
#define TAGGING_EUIDQ @"ext-id-returning"

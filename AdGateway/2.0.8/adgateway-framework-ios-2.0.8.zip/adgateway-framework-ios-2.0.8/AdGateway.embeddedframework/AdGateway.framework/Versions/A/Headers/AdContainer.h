//
//  AdContainer.h
//  AdGatewayFramework
//
//  Created by André  on 2013-05-21.
//  Copyright (c) 2013 Dohi Sweden. All rights reserved.
//


#import <UIKit/UIKit.h>
#import "AdSettings.h"
#import "DSAdProviderType.h"

typedef enum {
    AdContainerPlacementTypeInline,
    AdContainerPlacementTypeInterstitial
} AdContainerPlacementType;

@protocol AdContainerDelegate;

/**
 An object of AdContainer is used to visually present banners within its frame. When a user clicks a banner, the AdContainer handles all functionality regarding how the ad should be displayed depending on the ad's associated type and information.
 
 If specified in the ad targeting (through the campaign managers' admin interface, the AdContainer will also add/replace an ad-URL's query content with required information. Such information could be the local device's geographic position, manufacturer, os version and more. These values are the cornerstone of Ad Gateway's dynamic ads.
 @since 1.0
 */
__attribute__((visibility("default"))) @interface AdContainer : UIView

@property (nonatomic, retain) AdSettings *adSettings;

/**
 A delegate implementing the AdContainerDelegate protocol.
 @since 1.0
 */
@property (nonatomic, assign) id<AdContainerDelegate> delegate;

/**
 The Ad Provider URL. This URL is used to load creatives from the Ad Provider.
 @since 2.0
 */
@property (nonatomic, copy)   NSString *adProviderURL;

/**
 The Ad Provider type. Default value is AdProviderTypeCustom.
 If this property is set to something else then default value following properties are ignored:
    - adProviderQuerystringSeparator
    - adProviderKeywordSeparator
    - adProviderKeywordParameter
 @since 2.0
 */
@property (nonatomic, assign) AdProviderType adProviderType;

/**
 The Ad Provider querystring separator. Default value is '?' (Without the quotes).
 Example URL: http://www.theexampeladprovider.com/ads?cid=20;alias=1230;keywords=apple+banana
 */

@property (nonatomic, copy) NSString *adProviderBaseURLSeparator;
/**
 The Ad Provider querystring separator. Default value is ';' (Without the quotes).
 Example URL: http://www.theexampeladprovider.com/ads?cid=20;alias=1230;keywords=apple+banana
 */

@property (nonatomic, copy) NSString *adProviderQuerystringSeparator;

/**
 The Ad Provider keywords separator. Default value is '+' (Without the quotes).
 Example URL: http://www.theexampeladprovider.com/ads?cid=20;alias=1230;keywords=apple+banana
 */
@property (nonatomic, copy) NSString *adProviderKeywordSeparator;

/**
 The Ad Provider keyword parameter. Default value is 'keywords' (Without the quotes).
 Example URL: http://www.theexampeladprovider.com/ads?cid=20;alias=1230;keywords=apple+banana
 */
@property (nonatomic, copy) NSString *adProviderKeywordParameter;

/**
 The name-value pairs used to create a custom ad provider URL from the default URL.
 Each name-value pair replaces name-value-parameters of the default ad URL when requesting an ad with the call loadAd().
 Since 2.0.6 this property is readonly and only a copy of the original key value pairs. Adding and removing key value pairs should be done using the following methods from now on:
    - (void)addAdProviderValue:(NSString*)value withKey:(NSString*)key;
    - (void)removeAdProviderValue:(NSString*)value withKey:(NSString*)key;
 
 @since 1.0
 */
@property (nonatomic, retain, readonly) NSMutableDictionary *adProviderKeyValuePairs;

/**
 Method to set extra keywords that will be merged
 with the keywords from AdGateway
 @since 1.0.4
 */
@property (nonatomic, retain) NSArray *extraKeywords;

/**
 Sets the viewable state for AdContainer.
 This state can be received by loaded Creative.
 Default value: YES
 @since 2.0
 */

/**
 Sets wether inline AdContainer is within view.
 This state is used to override viewability state as determined
 by the AdContainer itself, for instance when the AdContainer is scrolled
 out of view. Something not detectable by AdContainer.
 Default value: YES
 @since 2.0
 */
@property (nonatomic, assign) BOOL isWithinView;

/**
 The placement type for advertisements displayed within the ad container.
 Default value: AdContainerPlacementTypeInline
 @since 2.0
 */
@property (nonatomic, assign, readonly) AdContainerPlacementType placementType;

/**
 Initializes the AdContainer with a frame to present the ad in, and its associated AdSettings object.
 @param frame the frame to contain the ad content.
 @param settings an AdSettings object that holds all settings for this container.
 @return returns an initialized AdContainer with associated frame and AdSettings.
 @since 1.0
 */
- (id)initWithFrame:(CGRect)frame settings:(AdSettings *)settings;

/**
 Initializes the AdContainer with a frame to present the ad in, and its associated AdSettings object.
 @param frame the frame to contain the ad content.
 @param settings an AdSettings object that holds all settings for this container.
 @param providerURL Ad Provider URL
 @return returns an initialized AdContainer with associated frame, AdSettings and Ad Provider URL.
 @since 2.0
 */
- (id)initWithFrame:(CGRect)frame settings:(AdSettings *)settings providerURL:(NSString *)providerURL;

/**
 Initializes the AdContainer with a frame to present the ad in, and its associated AdSettings object.
 @param frame the frame to contain the ad content.
 @param settings an AdSettings object that holds all settings for this container.
 @param providerURL Ad Provider URL
 @param placementType The placement type as returned by mraid.getPlacementType(), controls whether the
 advertisements are displayed inline or as interstitials.
 @return returns an initialized AdContainer with associated frame, AdSettings and Ad Provider URL.
 @since 2.0
 */
- (id)initWithFrame:(CGRect)frame settings:(AdSettings *)settings providerURL:(NSString *)providerURL placementType:(AdContainerPlacementType)placementType;

/**
 Called to initiate an Ad Request. This is done asynchronuously. It is thread safe. If it completes successfully, the view associated with this AdContainer will display the ad result. Information of the the new target (the ad URL) will be available.
 @since 1.0
 */
- (void)loadAd;

/**
 Close expanded creative and/or resizes AdContainer back to default size.
 @since 2.0
 */
- (void)close;

/**
 The modal presentation style for the presenting view controller when presenting a expand creative. The default value is UIModalPresentationCurrentContext.
 @since 2.0.4
 */
@property (nonatomic, assign) UIModalPresentationStyle presentingViewControllerModalPresentationStyle;

/**
 The modal presentation style for the expand view controller when presenting a expand creative. On iOS 8 and later this defaults to UIModalPresentationOverCurrentContext
 @since 2.0.4
 */
@property (nonatomic, assign) UIModalPresentationStyle expandViewControllerModalPresentationStyle;

/**
 Send message to the loaded ad. 
 
 The Ad will have to register an JS event listener for the event 'appMessageEvent' to receive the message.
 
 @param message Simple string of whatever format.
 @since 2.0.4
 */
- (void)sendMessageToAd:(NSString *)message;

/**
 Methods to individiually set search values
 @since 1.0.3
 */
- (void)setSearch1: (NSString *)value;
/**
 Methods to individiually set search values
 @since 1.0.3
 */
- (void)setSearch2: (NSString *)value;
/**
 Methods to individiually set search values
 @since 1.0.3
 */
- (void)setSearch3: (NSString *)value;

/**
 Inserts a key-value pair used to replace key-values of the default ad
 URL when requesting an ad. If the key is already added, its value will be replaced.
 @since 2.0.6
 */
- (void)addAdProviderValue:(NSString*)value withKey:(NSString*)key;

/**
 Removes a key-value pair from the list of key-value pairs used to create
 custom URL requests.
 @since 2.0.6
 */
- (void)removeAdProviderValuewithKey:(NSString*)key;

@end

#pragma mark - Delegate
/**
 @since 2.0
 */
@protocol AdContainerDelegate <NSObject>

@required
/**
 Delete method
 @param adContainer The AdContainer object
 @return The ViewController where expanded creatives be added to.
 @since 2.0
 */
- (UIViewController *)adContainerNeedsViewController:(AdContainer *)adContainer;

@optional
/**
 Tells the delegate that AdContainer is about to open URL.
 @param adContainer The AdContainer object
 @param URL Url to be opened.
 @param externalBrowser YES if the creative wants to open the URL in Safari
 @since 2.0
 */
- (BOOL)adContainer:(AdContainer *)adContainer openURL:(NSString *)URL externalBrowser:(BOOL)externalBrowser;

/**
 Tells the delegate that inline banner did finish loading creative.
 @param adContainer The AdContainer object
 @since 2.0
 */
- (void)adContainerDidFinishLoad:(AdContainer *)adContainer;

/**
 Tells the delegate that AdContainer will open banner in expanded state
 @param adContainer The AdContainer object
 @since 2.0
 */
- (BOOL)adContainerWillExpand:(AdContainer *)adContainer;

/**
 Tells the delegate that AdContainer did open banner in expanded state
 @param adContainer The AdContainer object
 @since 2.0
 */
- (void)adContainerDidExpand:(AdContainer *)adContainer;

/**
 Tells the delegate that expand did close and/or resized did resize back to default size.
 @param adContainer The AdContainer object
 @since 2.0
 */
- (void)adContainerDidChangeBackToDefaultState:(AdContainer *)adContainer;

/**
 Tells the delegate that an error did occur.
 
 Error codes:
 - <b>100</b> Error occurred in WebView.
 - <b>101</b> Creative caused an error. All errors sent to creative should also be sent to app.
 - <b>102</b> Unable to get keywords. Continue to load ad without keywords.
 - <b>103</b> Unable to get geo position. Getting keywords without geo position data.
 - <b>104</b> Unable to store an asset on the local device.
 
 - <b>200</b> Unable to load ad using Provider URL.
 
 - <b>300</b> Bad integration of framework. Value is nil.
 - <b>301</b> Bad integration of framework. Value is nil.
 - <b>302</b> Bad integration of framework. Value is nil or not UIViewController class.
 
 @param adContainer The AdContainer object
 @param error The error object that contains error code and error message.
 @since 2.0
 */
- (void)adContainer:(AdContainer *)adContainer didFailWithError:(NSError *)error;

/**
 Asks the delegate if inline banner should resize.
 @param adContainer The AdContainer object
 @param size The size the creative want to resize to
 @since 2.0
 */
- (BOOL)adContainer:(AdContainer *)adContainer shouldResizeTo:(CGRect)size;

/**
 Tells the delegate that AdContainer has been resized.
 @param adContainer The AdContainer object
 @param size The size the AdContainer resized to.
 @since 2.0
 */
- (void)adContainer:(AdContainer *)adContainer didResizeTo:(CGRect)size;

/**
 Tells the delegate that AdContainer will open video player.
 Only invoked if the creatives is using mraid.playVideo();
 @param adContainer The AdContainer object
 @param URL The video URL
 @since 2.0
 */
- (BOOL)adContainer:(AdContainer *)adContainer willOpenVideo:(NSString *)URL;

/**
 Tells the delegate that AdContainer did finish playing video
 This callback is only invoked if the creatives is using mraid.playVideo();
 @param adContainer The AdContainer object
 @since 2.0
 */
- (void)adContainerDidFinshPlayingVideo:(AdContainer *)adContainer;

/**
 Tells the delegate that AdContainer will open embedded browser.
 @param adContainer The AdContainer object
 @since 2.0
 */
- (void)adContainerWillOpenEmbeddedBrowser:(AdContainer *)adContainer;


/**
 Tells the delegate that AdContainer did close embedded browser.
 @param adContainer The AdContainer object
 @since 2.0
 */
- (void)adContainerDidCloseEmbeddedBrowser:(AdContainer *)adContainer;

/**
 Tells the delegate that an Ad did send a message to the app.
 
 @param adContainer AdContainer object
 @param message     Message from Ad. NSString of no particular format.
 @since 2.0.4
 */
- (void)adContainer:(AdContainer *)adContainer didReceiveMessageFromAd:(NSString *)message;

@end

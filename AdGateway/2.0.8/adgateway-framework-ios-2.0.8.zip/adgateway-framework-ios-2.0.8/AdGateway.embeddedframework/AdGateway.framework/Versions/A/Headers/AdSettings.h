//
//  AdSettings.h
//
// @author Mikael Jonsen, mikael@dohi.se
// @author Magnus Söderlund, magnus@dohi.se
//
// Modified by Per Mafrost. 2012-11-27 -> 2012-12-14
// Copyright 2012 Dohi Sweden AB. All rights reserved.
//
// @version 1.0
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>

typedef enum {
    CoarsePrecision,
    FinePrecision
} AdGeoPrecision;

typedef NS_OPTIONS(NSUInteger, AdSettingsDebugMask) {
    AdSettingsDebugMaskNone               = 0,
    AdSettingsDebugFlagAdContainer        = 1 << 0,
    AdSettingsDebugFlagAdKeywordFetcher   = 1 << 1,
    AdSettingsDebugFlagAdSettings         = 1 << 2,
    AdSettingsDebugFlagAdRequest          = 1 << 3,
    AdSettingsDebugMaskAll                = ~0
};

/**
 This class represents a settings object to associate with an AdContainer.

 It holds all settings associated with each AdContainer, controlling which information the developer wishes to use in Ad Gateway requests and manages all issues related to fetching, updating and standardizing the requested information to comply with the internal Ad Gateway rest API.
 @since 1.0
 */
__attribute__((visibility("default"))) @interface AdSettings : NSObject

/**
 The maximum request timeout towards the gateway requests.
 @since 1.0
 */
@property (nonatomic, assign) NSTimeInterval gatewayRequestTimeout;

/**
 The gateway hostname used to retrieve ad provider keywords from the ad gateway server.
 @since 2.0
 */
@property (nonatomic, readonly, copy) NSString *gatewayHost;

/**
 The gateway account which contains registered keywords.
 @since 1.0
 */
@property (nonatomic, readonly) NSString *gatewayAccount;

/**
 The application name used to retrieve registered keywords from gateway accounts.
 @since 1.0
 */
@property (nonatomic, readonly) NSString *appName;

/**
 The device ID for this application.
 @since 1.0
 */
@property (nonatomic, readonly) NSString *deviceID;


/**
 The current advertising ID for this device. Is nil if the user has disabled advertising tracking.
 @since 2.0.6
 */
@property (nonatomic, readonly) NSString *advertisingID;

/**
 True if the advertising id should be used, false if the device id should be used.
 Default is true. If the user has disabled advertising tracking, this property has no effect.
 @since 2.0.6
 */
@property (nonatomic, readonly) BOOL useAdvertisingID;

/**
 The current device location if geo positioning is active. Can be activated using startGeoPositioning().
 @since 1.0
 */
@property (nonatomic, copy) CLLocation *currentLocation;

/**
 Controls whether links are allowed to be opened in an external application or not. If this value
 is set to true and a link could not be opened internally, then it will be ignored.
 @since 2.0
 */
@property (nonatomic, assign) BOOL externalBrowserDisabled;

/**
 The debug mask used to filter debug messages.
 @since 2.0
 */
@property (nonatomic, assign) AdSettingsDebugMask debugMask;

/**
 If set, this location will be used UNTIL real hardware position is acquired.
 Will also be used when user denies location sharing or in case of hardware errors.
 @since 2.0.4
 */
@property (nonatomic, copy) CLLocation *staticLocation;

/**
 Do not call this method.
 @returns returns an uninitialized AdSettings object.
 @exception InvalidMethodException as this method should not be called.
 @since 1.0
 */
- (id)init;

/**
 Initializes the AdSettings object in its simplest form, using only account and appname.
 
 @param account Your Ad Gateway account.
 @param appname Unique application name to this application/company.
 @return an initialized AdSettings object.
 @exception NSInvalidArgumentException if providerURL is nil or an empty string.
 @since 2.0
 */
- (id)initWithAccount:(NSString *)account appname:(NSString *)appname;

/**
 Initializes the AdSettings object by setting its associated gatewayURL
 (which will be the basis of all requests, as a fallback security if the timeout
 of requests is exceeded -- or any error is thrown, that the developer does not
 implement error handling for).
 
 @param hostname The hostname to the AdGateway API.
 @param account Your Ad Gateway account.
 @param appname Unique application name to this application/company.
 @return an initialized AdSettings object.
 @since 2.0
 */
- (id)initWithHostname:(NSString *)hostname account:(NSString *)account appname:(NSString *)appname;

/**
 Returns the operating system name of this device. 
 @return returns the operating system name of this device.
 @since 1.0
 */
- (NSString *)osName;

/**
 Returns the operating system version.
 @return returns the currently running operating system's version.
 @since 1.0
 */
- (NSString *)osVersion;

/**
 Returns the name of the device manufacturer.
 @return the manufacturer of the currently used device.
 @since 1.0
 */
- (NSString *)manufacturer;

/**
 Returns the name of the device model.
 @return the device model of the currently used device.
 @since 1.3
 */
- (NSString *)deviceModel;

/**
 Returns the name of the currently used mobile carrier.
 @return the currently used mobile carrier
 @since 1.0
 */
- (NSString *)carrier;

/**
 Returns the current connection type.
 @return returns the current connection. "MobileCarrier", "Wifi" or nil.
 @since 1.0
 */
- (NSString *)connectionType;

/**
 Returns the screen height.
 @return returns the screen height.
 @since 1.2
 */
- (NSString *)screenHeight;

/**
 Returns the screen width.
 @return returns the screen width.
 @since 1.2
 */
- (NSString *)screenWidth;

/**
 Returns the framework version.
 @return returns the framework version.
 @since 1.2
 */
- (NSString *)frameworkVersion;

/**
 Returns the platform.
 @return returns the platform.
 @since 1.2
 */
- (NSString *)platform;

/**
 Returns the platform.
 @return returns the platform.
 @since 1.2
 */



/**
 Call this method to initiate geo positioning.
 @since 1.0
 */
- (void)startGeoPositioning;

/**
 Call this method to stop geo positioning.
 @since 1.0
 */
- (void)stopGeoPositioning;

/**
 Call this method to see if geo positioning is active.
 @returns returns YES if geo positioning is active, otherwise NO.
 @since 1.0
 */
- (BOOL)geoPositioningActive;

/**
 Call this method to retrieve the current user position.
 @returns returns the current user position.
 @since 1.0
 */
- (CLLocation *)geoPosition;

/**
 Sets the interval between consecutive position retrievals.
 
 Note that this value is the guaranteed minimum interval, it says nothing about the actual time between consecutive updates -- this is generally controlled by the underlying OS implementation and is monitored by hardware interrupts for HW GPS sensors. They are generally controlled by deltaDistance and deltaTime measurements as the user changes location.

 @param interval the interval between retrieving position. Will default to DEFAULT_POSITIONING_INTERVAL (60) if set to less than 1 minute.
 @throws IllegalArgumentException if interval is less than 0.
 @since 1.0
 */
- (void)setGeoPositioningInterval:(NSTimeInterval)interval;

/**
 Returns the currently set minimum time interval between two consecutive location updates. 
 
 Note that this value is the guaranteed minimum interval, it says nothing about the actual time between consecutive updates -- this is generally controlled by the underlying OS implementation and is monitored by hardware interrupts for HW GPS sensors. They are generally controlled by deltaDistance and deltaTime measurements as the user changes location.
 @return the minimum interval between consecutive location updates in seconds
 @since 1.0
 */
- (NSTimeInterval)geoPositioningInterval;

/**
 Sets the requested precision accuracy for positioning.

 The developer can choose to only use COARSE location updates, which will never use the GPS, or set it to FINE to also use GPS. COARSE location updates will still use our internal logic to find the most suitable provider -- and match the results from IP/mobile network triangulation.

 @param accuracy the desired precision can be PROVIDER_FINE or PROVIDER_COARSE.
 @since 1.0
 */
- (void)setGeoPositioningAccuracy:(AdGeoPrecision)accuracy;

/**
 Returns the currently associated precision which is used for location updates.
 @return the precision used on location updates.
 @since 1.0
 */
- (AdGeoPrecision)geoPositioningAccuracy;

/**
 Returns whether the given mask is a subset of the set debug mask or not.
 @param mask the mask to match the current debug mask against.
 @return true if the current debug mask matches the given mask.
 @since 2.0
 */
- (BOOL)debugMaskMatches:(AdSettingsDebugMask)mask;


// TODO: comment
- (NSDictionary *)deviceInformation;

@end

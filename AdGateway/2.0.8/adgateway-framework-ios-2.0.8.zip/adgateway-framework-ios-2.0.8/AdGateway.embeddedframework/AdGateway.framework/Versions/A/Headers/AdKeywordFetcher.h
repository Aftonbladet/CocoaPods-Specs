//
//  AdKeywordFetcher.h
//  AdGateway_iOS
//
//  Created by André on 2013-03-25.
//  Copyright 2013 Dohi Sweden AB. All rights reserved.
//
#import "AdSettings.h"

/**
 AdKeywordFetcher is used to retrieve only keywords from AdGateway.
 @since 1.4
 */
__attribute__((visibility("default"))) @interface AdKeywordFetcher : NSObject

/**
 The AdSettings object.
 @since 1.4
 */
@property (nonatomic, retain) AdSettings *adSettings;

/**
 The search values list. The list is used to compose the gateway request with search values. Only the first three values will be used.
 @since 1.4
 */
@property (nonatomic, readonly) NSDictionary *adGatwaySearchValues;

/**
 Initializes this AdKeywordFetcher object with the supplied AdSettings object.
 @param settings dSettings object.
 @returns returns an initialized AdKeywordFetcher object.
 @exception InvalidMethodException if adSettings is nil.
 @since 1.4
 */
- (id)initWithAdSettings:(AdSettings *)settings;

/**
 @since 1.4
 */
- (void)getKeywords:(void (^)(NSArray *keyword))successHandler errorHandler:(void (^)(NSError *))errorHandler;

/**
 Methods to individiually set search values
 @since 1.4
 */
- (void)setSearch1: (NSString *)value;
/**
 Methods to individiually set search values
 @since 1.4
 */
- (void)setSearch2: (NSString *)value;
/**
 Methods to individiually set search values
 @since 1.4
 */
- (void)setSearch3: (NSString *)value;

@end

//
//  AdProviderType.h
//  AdGatewayFramework
//
//  Created by Mattias Bergström on 05/11/14.
//  Copyright (c) 2014 Dohi Sweden. All rights reserved.
//

#ifndef AdGatewayFramework_AdProviderType_h
#define AdGatewayFramework_AdProviderType_h

typedef enum {
    AdProviderTypeCustom,
    AdProviderTypeEmediate,
    AdProviderTypeAdTech
} AdProviderType;

#endif

# iOS framework HOWTO

This is a step by step guide detailing how to add Ad Gateway support to any iOS application with a minimum iOS SDK requirement of **5.0**.

## Introduction

The Ad Gateway iOS framework is bundled as an embedded framework. You need to drag the framework file into your project and import the convenience header `AdGateway.h` to get started.

## Integration

There are several steps to a successful Ad Gateway integration. First you must import and set up the Ad Gateway Framework (AGF) into your project. Then you must write some code to run the framework.

_The following instructions are based on Xcode 4.2. Other versions of Xcode can (and will) look different_

__Importing the embedded framework__

1.	Open or create a project in Xcode
2.	Include the AGF files
    1.	From the '*File*' menu, chose 'Add Files to "Your Project Name"...'
    2.	Navigate to the '*AdGateway.embeddedframework*-folder and select it
    3.	Make sure that '*Create groups for any added folders*' is selected
    4.	Check the targets that should include AGF
    5.	Click '*Add*'
3.	Add the frameworks needed to compile your project with AGF
    1.	Navigate to the project settings directory
    2.	Choose a target including AGF and click '*Build Phases*'
    3.	Make sure the following frameworks are added:
        - AdGateway
        - UIKit
        - Foundation
        - CoreGraphics
        - CoreLocation
        - CFNetwork
        - SystemConfiguration
        - MediaPlayer
        - EventKit
        - EventKitUI
        - CoreTelephony

By following these steps, the project is now set up and you can start using AGF.

__Integration into code__

For a full specification, please refer to the API documentation. This description will get you going.

1.	Initialize an `AdSettings` object
	- The `gatewayAccount` is the account assigned to your company.
	- The `applicationName` is the name of your application / site.
2.	Initialize an `AdContainer` object with a frame (height greater than 0) and the `AdSettings` object.
	- The `providerURL` should point to an existing ad provider campaign.
		- It is used to provide a fallback if something goes wrong.
		- It is used as a base URL for replacements and keyword / campaign ID insertion.
3.	Add the `AdContainer` to a view where you want your ad to be displayed.
4.  Set a delegate for the `AdContainer`.
	- This delegate is required to implement the method `- (UIViewController *)adContainerNeedsViewController:(AdContainer *)adContainer` which should return the view controller that `AdContainer` belongs to.
	- It is also advised to implement the methods concerning resizing to allow `mraid` advertisements to resize themselves.
5.	Call `loadAd` on the `adContainer`.

Note that the same `AdSettings` object can be used for multiple `AdContainers`, or individual settings can be assigned to specific ad positions (`AdContainers`).

## Integration of AdKeywordFetcher

This sections describes how to integrate only the keyword fetcher into your application.

### AdSettings

The AdSettings object contains various information related to the device your app
is running on.

* OS
* OS Version
* Device model
* Device manufacturer
* Device ID / Advertisement ID
* Screen size
* Connection type (WiFi, Mobile network)
* Carrier (Telia, Tele2, etc.)
* Location

These (with the exception off location information) are automatically gathered when the
AdSettings objects is instantiated.

You can tell an AdSettings object to start and stop collecting location information by
using the methods `startGeoPositioning` and `stopGeoPositioning`.
The interval between position updates can be set by `setGeoPositioningInterval:(NSTimeInterval)interval`.
More information about these functions can be found in the documentation for AdGateway.

In order to allow the Keyword Fetcher to work with the Ad Gateway servers you need
to supply an account and an application name by calling the
constructor: `initWithAccount(NString*)account appname:(NSString*)appname`

If you have received a separate hostname to use, you should instead call the
other constructor `initWithHostname:(NSString*)hostname account:(NSString*)account appname:(NSString*)appname`


### AdKeywordFetcher

To use the AdKeywordFetcher you need first use the constructor `initWithAdSettings:(AdSettings*)settings`.
The AdSettings are needed by AdKeywordFetcher to know what parameters to send to the Ad Gateway server.

To get keywords, use the method `(void)getKeywords:(void (^)(NSArray *keywords))successHandler errorHandler:(void (^)(NSError *error))errorHandler`
This will execute an asynchronous request against the Ad Gateway server, and using the blocks as callback functions.

The `successHandler` block will be called if the keyword requests succeeds.
Note that the array of keywords can be empty if no matching ad was found.

If the request does not succeeds, the block `errorHandler` will be called. This can happen if the servers are unreachable, or if the request you made couldn't be understood by the servers(invalid account for example).
The message of the error in the block can be retrived by calling `localizedDescription` on the error.

In addition to the parameters gathered by AdSettings you can supply up to three
search parameters of your own choosing.
This is done with the methods `setSearch1:(NSString*)value`, `setSearch2:(NSString*)value` and `setSearch3:(NSString*)value`.

Only keywords associated with ads that
contain these search parameters will be returned when fetching keyword.
This functionality can for example be used to limit some ads to only be
displayed in certain locations in your app.
If you're not using search parameters the AdSettings object can be reused for
several AdKeywordFetcher objects.

### Example Implementation

~~~~~~~~~~~~~~~~~~~~{.objc}
#import "DSKeyfetcherExampleTableViewController.h"
#import <AdGateway/AdGateway.h>

@interface DSKeyfetcherExampleTableViewController ()
@property AdSettings* settings;
@property AdKeywordFetcher* fetcher;
@end

@implementation DSKeyfetcherExampleTableViewController

-(void)viewDidLoad{
    [super viewDidLoad];
    [self requestKeywords];
}

-(void)requestKeywords{
    // Init AdSettings with given acc/app
    _settings = [[AdSettings alloc] initWithAccount:@"test_acc" appname:@"test_app"];

    // Activate logging for Keyword Fetcher
    // Can be omitted if no logging is wanted
    [_settings setDebugMask:AdSettingsDebugFlagAdKeywordFetcher];

    // Collect location information
    // NOTE: Location permission is left to host application, and is not requested by the framework.
    [_settings startGeoPositioning];

    // Set LocationManager granularity depending on needs.
    // Accepted values are CoarsePrecision or FinePrecision.
    [_settings setGeoPositioningAccuracy:CoarsePrecision];

    // Create the fetcher with the defined AdSettings, and run asyncronous call to get
    // keywords from the Ad Gateway server.
    _fetcher = [[AdKeywordFetcher alloc] initWithAdSettings:_settings];
    [_fetcher getKeywords:^(NSArray *keywords) {
        // Success block, request did not have any errors.
        if(keywords.count < 1 ){
            // No matching keywords
        } else {
            // We found matching keywords
        }
    } errorHandler:^(NSError *error) {
        // Error while getting keywords
    }];
}
~~~~~~~~~~~~~~~~~~~~

__Updating to version 2.0__

When updating to version 2.0 there a lot of calls such as `hideAdvertisementViews` and `removeVerticalPopupPadding:` have been removed from `AdContainer`. The delegate methods have also been completely revamped and will need to be updated accordingly. The `defaultProviderURL` passed to the `AdSettings` object is now passed to the `AdContainer` instead, and the `keywordIdentifier` can be set on the `AdContainer` object after initialization using the `adProviderKeywordParameter` property.

__Resize__

The framework gives you a way of reacting to changes in ad container size, by implementing the `AdContainerDelegate` protocol. Integrate Ad Gateway as usual, and set the `AdContainer`s `delegate` property.

For example, you can have the integrating class handle resizes.

~~~~~~~~~~~~~~~~~~~~{.objc}
self.adContainer.delegate = self
~~~~~~~~~~~~~~~~~~~~

Implement the delegate method, returning a suitable boolean.

~~~~~~~~~~~~~~~~~~~~{.objc}
- (BOOL)adContainer:(AdContainer *)adContainer shouldResizeTo:(CGRect)size
{
    return YES;
}

- (void)adContainer:(AdContainer *)adContainer didResizeTo:(CGRect)size
{
    // Perform re-layout of views as needed
}

~~~~~~~~~~~~~~~~~~~~


### Caveats
To overcome certain limitations, the framework overrides certain shared objects in the application's execution environment in order to provide for a better user experience.

- The shared `NSURLCache` is replaced with an URL cache that will handle dynamic loading of the `mraid.js` file.
- The shared `NSHTTPCookieStorage` is modified to have the `NSHTTPCookieAcceptPolicyAlways` policy in order to allow cookies to be set for redirects.

AdGateway is nonetheless able to function even if modifications to these areas were made.

### Known Issues
- `target=_blank` links handle poorly, and should instead be replaced by `mraid.open` calls. The framework is able to open such links in an external browser but the source advertisement is also affected and will switch page. This is due to a limitation in `UIWebView`.

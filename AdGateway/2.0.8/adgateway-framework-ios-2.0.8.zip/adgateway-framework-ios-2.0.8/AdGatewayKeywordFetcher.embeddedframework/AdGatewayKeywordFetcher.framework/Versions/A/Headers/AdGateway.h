//
//  AdGateway.h
//  AdGatewayFramework_iOS
//
//  Header file to import all necessary headers.
//
//  Created by Mikael Jonsen on 12/1/11.
//  Copyright (c) 2011 Dohi Sweden AB. All rights reserved.
//

#ifndef AdGatewayFramework_iOS_AdGateway_h
#define AdGatewayFramework_iOS_AdGateway_h

#import "AdSettings.h"
#import "AdKeywordFetcher.h"

#endif

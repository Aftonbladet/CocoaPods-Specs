var searchData=
[
  ['placementtype',['placementType',['../interface_ad_container.html#a0d7fcd5cdc8e998b5bc75ff36c57c6cb',1,'AdContainer']]],
  ['platform',['platform',['../interface_ad_settings.html#af46f581df49ac5663f6d91289221656d',1,'AdSettings']]],
  ['presentingviewcontrollermodalpresentationstyle',['presentingViewControllerModalPresentationStyle',['../interface_ad_container.html#aeb1ec4dd6f28f4352795a43d0dc07a9d',1,'AdContainer']]]
];

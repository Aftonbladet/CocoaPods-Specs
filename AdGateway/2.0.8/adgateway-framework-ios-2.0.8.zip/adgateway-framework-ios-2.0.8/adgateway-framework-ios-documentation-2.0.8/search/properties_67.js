var searchData=
[
  ['gatewayaccount',['gatewayAccount',['../interface_ad_settings.html#a2e2d9078b4e2b204fce8974251c0bb06',1,'AdSettings']]],
  ['gatewayhost',['gatewayHost',['../interface_ad_settings.html#a8c8dc9c765611731e9a28a980d876960',1,'AdSettings']]],
  ['gatewayrequesttimeout',['gatewayRequestTimeout',['../interface_ad_settings.html#a866589e10cb4066ee1d4f68e2ff8002f',1,'AdSettings']]]
];

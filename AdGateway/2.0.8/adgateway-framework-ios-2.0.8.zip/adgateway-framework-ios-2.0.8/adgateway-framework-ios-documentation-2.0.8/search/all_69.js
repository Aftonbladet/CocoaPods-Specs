var searchData=
[
  ['init',['init',['../interface_ad_settings.html#aaab6e0493a9bac4bd52f806896914875',1,'AdSettings']]],
  ['initwithaccount_3aappname_3a',['initWithAccount:appname:',['../interface_ad_settings.html#aaa400c5b2a0b4d49814952de49240a38',1,'AdSettings']]],
  ['initwithadsettings_3a',['initWithAdSettings:',['../interface_ad_keyword_fetcher.html#aad94511af675d1ebcb5024ae57904e82',1,'AdKeywordFetcher']]],
  ['initwithframe_3asettings_3a',['initWithFrame:settings:',['../interface_ad_container.html#a90b3ed1d1f52c4d6404ce90631600773',1,'AdContainer']]],
  ['initwithframe_3asettings_3aproviderurl_3a',['initWithFrame:settings:providerURL:',['../interface_ad_container.html#a25ae2f9b9e33c9239dd4018b499f2ec6',1,'AdContainer']]],
  ['initwithframe_3asettings_3aproviderurl_3aplacementtype_3a',['initWithFrame:settings:providerURL:placementType:',['../interface_ad_container.html#aba6b0e43735e18343b8614b443e59db4',1,'AdContainer']]],
  ['initwithhostname_3aaccount_3aappname_3a',['initWithHostname:account:appname:',['../interface_ad_settings.html#a12281a90bf008bc50db91bbc73bc55ad',1,'AdSettings']]],
  ['iswithinview',['isWithinView',['../interface_ad_container.html#a3caef17e05a6e91aa3d707663785ac71',1,'AdContainer']]]
];

var searchData=
[
  ['staticlocation',['staticLocation',['../interface_ad_settings.html#a1ced0bd797c0b6d24559ee9b59f91283',1,'AdSettings']]]
];

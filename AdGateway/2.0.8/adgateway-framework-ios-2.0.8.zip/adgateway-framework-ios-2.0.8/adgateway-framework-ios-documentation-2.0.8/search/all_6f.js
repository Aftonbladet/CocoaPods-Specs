var searchData=
[
  ['osname',['osName',['../interface_ad_settings.html#a5d3caf29b3cb483857391775364db31f',1,'AdSettings']]],
  ['osversion',['osVersion',['../interface_ad_settings.html#af16746ce96b720745e3965bc8d7eda90',1,'AdSettings']]]
];

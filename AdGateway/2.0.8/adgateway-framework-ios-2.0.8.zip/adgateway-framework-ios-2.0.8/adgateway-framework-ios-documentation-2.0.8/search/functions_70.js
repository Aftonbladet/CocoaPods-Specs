var searchData=
[
  ['platform',['platform',['../interface_ad_settings.html#af46f581df49ac5663f6d91289221656d',1,'AdSettings']]]
];

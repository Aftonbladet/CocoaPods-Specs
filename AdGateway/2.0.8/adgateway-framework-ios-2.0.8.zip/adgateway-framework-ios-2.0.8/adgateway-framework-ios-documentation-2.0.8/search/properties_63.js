var searchData=
[
  ['currentlocation',['currentLocation',['../interface_ad_settings.html#a41765c76269dc9c1d9a34c640c7b72a8',1,'AdSettings']]]
];

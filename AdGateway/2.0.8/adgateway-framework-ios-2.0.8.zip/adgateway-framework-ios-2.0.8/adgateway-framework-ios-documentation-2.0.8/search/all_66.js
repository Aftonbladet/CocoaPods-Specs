var searchData=
[
  ['frameworkversion',['frameworkVersion',['../interface_ad_settings.html#a5d8b90b44fcf3cb7b47a91c053be44fe',1,'AdSettings']]]
];

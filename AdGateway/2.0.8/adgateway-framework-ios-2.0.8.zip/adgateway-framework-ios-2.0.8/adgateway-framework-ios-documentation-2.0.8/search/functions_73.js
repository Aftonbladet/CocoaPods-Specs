var searchData=
[
  ['screenheight',['screenHeight',['../interface_ad_settings.html#acf0c534daba25dd4019c9da5eb9dee7b',1,'AdSettings']]],
  ['screenwidth',['screenWidth',['../interface_ad_settings.html#a4308cb466ef377b247cc41104996bba6',1,'AdSettings']]],
  ['sendmessagetoad_3a',['sendMessageToAd:',['../interface_ad_container.html#ac3d52ed4dfe3d1c6a830826111fd4d96',1,'AdContainer']]],
  ['setgeopositioningaccuracy_3a',['setGeoPositioningAccuracy:',['../interface_ad_settings.html#aee098858825a6e619875c84cfa71af80',1,'AdSettings']]],
  ['setgeopositioninginterval_3a',['setGeoPositioningInterval:',['../interface_ad_settings.html#a117c6d96befa34f5762a3fdf612b236e',1,'AdSettings']]],
  ['setsearch1_3a',['setSearch1:',['../interface_ad_container.html#a1fbbe22cfbbcf4a9d1afcf35ae36e3ef',1,'AdContainer::setSearch1:()'],['../interface_ad_keyword_fetcher.html#aea002f1a361a00a2ea1c22767576e418',1,'AdKeywordFetcher::setSearch1:()']]],
  ['setsearch2_3a',['setSearch2:',['../interface_ad_container.html#a5fa49ae68c0ff57c15ebb0622479bf4c',1,'AdContainer::setSearch2:()'],['../interface_ad_keyword_fetcher.html#afd46bdaa0275932cc24cdce876ae2e09',1,'AdKeywordFetcher::setSearch2:()']]],
  ['setsearch3_3a',['setSearch3:',['../interface_ad_container.html#ad0696c0e8cfd3b8d996bd0546d3cda09',1,'AdContainer::setSearch3:()'],['../interface_ad_keyword_fetcher.html#aa9aee162fc3559e989bcd6937747bfaf',1,'AdKeywordFetcher::setSearch3:()']]],
  ['startgeopositioning',['startGeoPositioning',['../interface_ad_settings.html#a21f2286c5e12565d03cdafaac17f42ab',1,'AdSettings']]],
  ['stopgeopositioning',['stopGeoPositioning',['../interface_ad_settings.html#ac679eb42e9a5ea3d17f516570150c651',1,'AdSettings']]]
];
